-- Created by Gökmen Soysal

-- Schema FamilyHealthCenter
DROP SCHEMA IF EXISTS `FamilyHealthCenter` ;

CREATE SCHEMA IF NOT EXISTS `FamilyHealthCenter` DEFAULT CHARACTER SET utf8 ;
USE `FamilyHealthCenter` ;

-- Table Users
DROP TABLE IF EXISTS `FamilyHealthCenter`.`Users` ;

CREATE TABLE IF NOT EXISTS `FamilyHealthCenter`.`Users` (
  `idUsers` INT NOT NULL,
  `nameUsers` VARCHAR(45) NOT NULL,
  `surnameUsers` VARCHAR(45) NOT NULL,
  `passwordUsers` VARCHAR(45) NOT NULL,
  `phoneNumberUsers` VARCHAR(45) NOT NULL,
  `emailUsers` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idUsers`))
ENGINE = InnoDB;

INSERT INTO `FamilyHealthCenter`.`Users` (idUsers, nameUsers, surnameUsers, passwordUsers, phoneNumberUsers, emailUsers)
VALUES (1, 'Erman', 'Soysal', '12345', '0532 532 53 32', 'ermansoysal@gmail.com' );

INSERT INTO `FamilyHealthCenter`.`Users` (idUsers, nameUsers, surnameUsers, passwordUsers, phoneNumberUsers, emailUsers)
VALUES (2, 'Onur', 'Taş', '54321', '0507 507 50 07', 'onurtas@hotmail.com' );

INSERT INTO `FamilyHealthCenter`.`Users` (idUsers, nameUsers, surnameUsers, passwordUsers, phoneNumberUsers, emailUsers)
VALUES (3, 'Gökmen', 'Soysal', '101010', '0505 505 50 05', 'gokmensoysal@gmail.com' );

-- Table CleaningSupplies
DROP TABLE IF EXISTS `FamilyHealthCenter`.`CleaningSupplies` ;

CREATE TABLE IF NOT EXISTS `FamilyHealthCenter`.`CleaningSupplies` (
  `idCleaningSupplies` INT NOT NULL,
  `nameCleaningSupplies` VARCHAR(45) NOT NULL,
  `priceCleaningSupplies` VARCHAR(45) NOT NULL,
  `quantityCleaningSupplies` INT NOT NULL,
  `buyDateCleaningSupplies` VARCHAR(45) NOT NULL,
  `buyerCleaningSupplies` INT NOT NULL,
  PRIMARY KEY (`idCleaningSupplies`),
    FOREIGN KEY (`buyerCleaningSupplies`)
    REFERENCES `FamilyHealthCenter`.`Users` (`idUsers`)
)
ENGINE = InnoDB;

INSERT INTO `FamilyHealthCenter`.`CleaningSupplies` (idCleaningSupplies, nameCleaningSupplies, priceCleaningSupplies, quantityCleaningSupplies, buyDateCleaningSupplies, buyerCleaningSupplies)
VALUES (1, 'Cam Silme Suyu', '45', '3', '19.12.2022', 1 );

INSERT INTO `FamilyHealthCenter`.`CleaningSupplies` (idCleaningSupplies, nameCleaningSupplies, priceCleaningSupplies, quantityCleaningSupplies, buyDateCleaningSupplies, buyerCleaningSupplies)
VALUES (2, 'Sabun', '30', '5', '21.12.2022', 3);

INSERT INTO `FamilyHealthCenter`.`CleaningSupplies` (idCleaningSupplies, nameCleaningSupplies, priceCleaningSupplies, quantityCleaningSupplies, buyDateCleaningSupplies, buyerCleaningSupplies)
VALUES (3, 'Yer temizleyici', '120', '5', '24.12.2022', 2 );

-- Table MedicalSupplies
DROP TABLE IF EXISTS `FamilyHealthCenter`.`MedicalSupplies` ;

CREATE TABLE IF NOT EXISTS `FamilyHealthCenter`.`MedicalSupplies` (
  `idMedicalSupplies` INT NOT NULL,
  `nameMedicalSupplies` VARCHAR(45) NOT NULL,
  `priceMedicalSupplies` VARCHAR(45) NOT NULL,
  `quantityMedicalSupplies` INT NOT NULL,
  `expirationDateMedicalSupplies` VARCHAR(45) NOT NULL,
  `buyDateMedicalSupplies` VARCHAR(45) NOT NULL,
  `buyerMedicalSupplies` INT NOT NULL,
  PRIMARY KEY (`idMedicalSupplies`),
    FOREIGN KEY (`buyerMedicalSupplies`)
    REFERENCES `FamilyHealthCenter`.`Users` (`idUsers`)
)
ENGINE = InnoDB;

INSERT INTO `FamilyHealthCenter`.`MedicalSupplies` (idMedicalSupplies, nameMedicalSupplies, priceMedicalSupplies, quantityMedicalSupplies, expirationDateMedicalSupplies, buyDateMedicalSupplies, buyerMedicalSupplies)
VALUES (1, 'Aşi', '200', '5', '21.06.2024', '19.12.2022', 3 );

INSERT INTO `FamilyHealthCenter`.`MedicalSupplies` (idMedicalSupplies, nameMedicalSupplies, priceMedicalSupplies, quantityMedicalSupplies, expirationDateMedicalSupplies, buyDateMedicalSupplies, buyerMedicalSupplies)
VALUES (2, 'Sargi bezi', '100', '20', '-', '20.12.2022', 2 );

INSERT INTO `FamilyHealthCenter`.`MedicalSupplies` (idMedicalSupplies, nameMedicalSupplies, priceMedicalSupplies, quantityMedicalSupplies, expirationDateMedicalSupplies, buyDateMedicalSupplies, buyerMedicalSupplies)
VALUES (3, 'Batikon', '45', '3', '-', '24.12.2022', 1 );


-- Table FoodSupplies
DROP TABLE IF EXISTS `FamilyHealthCenter`.`FoodSupplies` ;

CREATE TABLE IF NOT EXISTS `FamilyHealthCenter`.`FoodSupplies` (
  `idFoodSupplies` INT NOT NULL,
  `nameFoodSupplies` VARCHAR(45) NOT NULL,
  `priceFoodSupplies` VARCHAR(45) NOT NULL,
  `quantityFoodSupplies` INT NOT NULL,
  `expirationDateFoodSupplies` VARCHAR(45) NOT NULL,
  `buyDateFoodSupplies` VARCHAR(45) NOT NULL,
  `buyerFoodSupplies` INT NOT NULL,
  PRIMARY KEY (`idFoodSupplies`),
    FOREIGN KEY (`buyerFoodSupplies`)
    REFERENCES `FamilyHealthCenter`.`Users` (`idUsers`)
)
ENGINE = InnoDB;

INSERT INTO `FamilyHealthCenter`.`FoodSupplies` (idFoodSupplies, nameFoodSupplies, priceFoodSupplies, quantityFoodSupplies, expirationDateFoodSupplies, buyDateFoodSupplies, buyerFoodSupplies)
VALUES (1, 'Makarna', '45', '3', '11.07.2025', '15.12.2022', 2 );

INSERT INTO `FamilyHealthCenter`.`FoodSupplies` (idFoodSupplies, nameFoodSupplies, priceFoodSupplies, quantityFoodSupplies, expirationDateFoodSupplies, buyDateFoodSupplies, buyerFoodSupplies)
VALUES (2, 'Turşu', '80', '2', '20.10.2023', '20.12.2022', 3 );

INSERT INTO `FamilyHealthCenter`.`FoodSupplies` (idFoodSupplies, nameFoodSupplies, priceFoodSupplies, quantityFoodSupplies, expirationDateFoodSupplies, buyDateFoodSupplies, buyerFoodSupplies)
VALUES (3, 'Peynir', '200', '2', '01.03.2024', '21.12.2022', 1 );


-- Table ElectronicSupplies
DROP TABLE IF EXISTS `FamilyHealthCenter`.`ElectronicSupplies` ;

CREATE TABLE IF NOT EXISTS `FamilyHealthCenter`.`ElectronicSupplies` (
  `idElectronicSupplies` INT NOT NULL,
  `nameElectronicSupplies` VARCHAR(45) NOT NULL,
  `priceElectronicSupplies` VARCHAR(45) NOT NULL,
  `quantityElectronicSupplies` INT  NOT NULL,
  `buyDateElectronicSupplies` VARCHAR(45) NOT NULL,
  `buyerElectronicSupplies` INT NOT NULL,
  PRIMARY KEY (`idElectronicSupplies`),
    FOREIGN KEY (`buyerElectronicSupplies`)
    REFERENCES `FamilyHealthCenter`.`Users` (`idUsers`)
)
ENGINE = InnoDB;

INSERT INTO `FamilyHealthCenter`.`ElectronicSupplies` (idElectronicSupplies, nameElectronicSupplies, priceElectronicSupplies, quantityElectronicSupplies, buyDateElectronicSupplies, buyerElectronicSupplies)
VALUES (1, 'Ampül', '105', '3', '19.12.2022', 1 );

INSERT INTO `FamilyHealthCenter`.`ElectronicSupplies` (idElectronicSupplies, nameElectronicSupplies, priceElectronicSupplies, quantityElectronicSupplies, buyDateElectronicSupplies, buyerElectronicSupplies)
VALUES (2, 'Elektrikli Süpürge', '450', '1', '21.12.2022', 2);

INSERT INTO `FamilyHealthCenter`.`ElectronicSupplies` (idElectronicSupplies, nameElectronicSupplies, priceElectronicSupplies, quantityElectronicSupplies, buyDateElectronicSupplies, buyerElectronicSupplies)
VALUES (3, 'Hoparlör', '250', '2', '22.12.2022', 3 );


